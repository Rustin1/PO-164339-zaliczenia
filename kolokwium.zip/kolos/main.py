from Vehicle import Vehicle
from Car import Car
c_1 = Vehicle("Nissan", 2, 550000, 10, True)
v_2 = Vehicle("Audi", 2, 990000.0, 140, 1000)
print(v_2)