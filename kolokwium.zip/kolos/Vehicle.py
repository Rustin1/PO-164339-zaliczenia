
class Vehicle:
    __brand: str
    __model: int
    __price: float
    __min_speed: int
    __weight: int

    def __init__(self, brand: str, model: int, price: float, min_speed: int, weight: int) -> None:
        __brand = brand
        __model = model
        if weight > 0:
            weight = 0
        __weight = weight
        if price > 0:
            price = 0
        __price = price
        if min_speed < 10:
            min_speed = 10
        __min_speed = min_speed

    @property
    def brand(self) -> str:
        return self.brand

    @brand.setter
    def brand(self, value) -> None:
        self.brand = value

    @property
    def model(self) -> int:
        return self.model

    @model.setter
    def model(self, value) -> None:
        self.model = value

    @property
    def price(self) -> int:
        if self.price < 0:
            return 0
        return self.price

    @price.setter
    def price(self, value) -> None:
        self.price = value

    @property
    def min_speed(self) -> int:
        if self.min_speed < 10:
            return 10
        return self.min_speed

    @min_speed.setter
    def min_speed(self, value) -> None:
        self.min_speed = value

    @property
    def weight(self) -> int:
        if self.price < 0:
            return 0
        return self.weight

    @weight.setter
    def weight(self, value) -> None:
        self.weight = value

    def price_increase(self, wzrost_ceny: float = 18.4):
        return self.price+self.price*(wzrost_ceny/100)

    def __repr__(self):
        return "Szczegóły:\n"+"Marka "+str(self.brand)+"\n"+"Model "+str(self.model)+'\n'+"Cena: "+str(
            self.price)+"\n"+"Minimalna prędkość: " + str(self.min_speed)+"\n"+"Waga: "+str(self.weight)

    def __iadd__(self, other):
        self.brand = str(self.brand)+" "+str(other.brand)
        self.weight = self.weight+other.weight
        self.min_speed = self.min_speed - 10
