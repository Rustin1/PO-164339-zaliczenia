from Vehicle import Vehicle


class Car(Vehicle):
    __is_combi: bool

    def __init__(self,brand: str, model: str, price: float, min_speed: int, weight: int, is_combi: bool):
        super().__init__(brand, model, price, min_speed, weight)
        if min_speed < 50:
            return 50
        __is_combi = is_combi
    @property
    def is_combi(self) -> bool:
        if not is_combi is True or not is_combi is False:
            return str("nie jest to możliwe")
        return is_combi

    @is_combi.setter
    def is_combi(self, value:int) -> None:
        is_combi = value

    def booltotak(self):
        if is_combi is True:
            return "tak"
        return "nie"

    def __iadd__(self, other) -> None:
        self.brand = str(self.brand) + " " + str(other.brand)
        self.weight = self.weight + other.weight
        self.min_speed = self.min_speed - 20

    def __repr__(self):
        return "Szczegóły:\n" + "Marka " + str(self.brand) + "\n" + "Model " + str(self.model) + '\n' + "Cena: " + str(
            self.price) + "\n" + "Minimalna prędkość: " + str(self.min_speed) + "\n" + "Combi: " + str(self.booltotak)

